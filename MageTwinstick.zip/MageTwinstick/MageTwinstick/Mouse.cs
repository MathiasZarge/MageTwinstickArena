﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MageTwinstick
{
    static class Mouse
    {
        //fields
        public static float X { get; set; }
        public static float Y { get; set; }
    }
}
